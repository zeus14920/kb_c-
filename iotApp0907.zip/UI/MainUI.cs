﻿using iotApp0907.Model;
using iotApp0907.Util;
using MaterialSkin.Controls;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using Timer = System.Threading.Timer;

namespace iotApp0907
{
    public partial class MainUI : MaterialForm
    {
        ThingSpeak ts = new ThingSpeak();
        ThingSpeakTimer sTimer, rTimer;

        string[] temp = { "15", "22", "38", "41", "57", "63", "77", "84", "92", "104" };
        string[] humi = { "15", "22", "38", "41", "57", "63", "77", "84", "92", "104" };

        Random r = new Random();

        public MainUI()
        {
            InitializeComponent();
            sTimer = new ThingSpeakTimer(new Timer(new TimerCallback(writeHandler), null, 1000, 20000));
            rTimer = new ThingSpeakTimer(new Timer(new TimerCallback(readHandler), null, 2000, 20000));
        }

        void writeHandler(object args)
        {
            bool chk = ts.sendDateToThingSpeak(temp[r.Next(10)], humi[r.Next(10)],
                    temp[r.Next(10)], humi[r.Next(10)], null, null, null, null);
            if (chk == true)
            {
                Console.WriteLine("데이터 전송 성공!");
            }
            else
            {
                Console.WriteLine("데이터 전송 실패!");
            }
        }

        void readHandler(object args)
        {
            List<LineEnvData> list = ts.readThingSpeak();
            for(int i = 0; i < list.Count; i++)
            {
                lineAddTime.Text = list[i].Time;
                lineOneTemp.Text = list[i].Temp1;
                lineOnehumi.Text = list[i].Humi1;
                lineTwoTempAnalogMeter.Value = Convert.ToDouble(list[i].Temp2);
                lineTwoHumiAnalogMeter.Value = Convert.ToDouble(list[i].Humi2);

                Console.WriteLine("시간: " + list[i].Time);
                Console.WriteLine("부품 1라인 온도: " + list[i].Temp1 + " ℃");
                Console.WriteLine("부품 1라인 습도: " + list[i].Humi1 + " %");
                Console.WriteLine("부품 2라인 온도: " + list[i].Temp2 + " ℃");
                Console.WriteLine("부품 2라인 습도: " + list[i].Humi2 + " %");

                Console.WriteLine("[부품 라인 모니터링 정보]");
                int nTemp1 = Convert.ToInt32(list[i].Temp1);
                if (nTemp1 < 20)
                {
                    lineOneTempBulb.Color = Color.Red;
                    Console.WriteLine("[온도 낮음]부품 1라인 히터 가동중입니다.");
                    new SoundPlayer(Properties.Resources.siren).Play();
                }
                else if(nTemp1 >21 && nTemp1 < 70)
                {
                    lineOneTempBulb.Color = Color.Green;
                    Console.WriteLine("부품 1라인 정상 가동중입니다.");
                }
                else
                {
                    lineOneTempBulb.Color = Color.Red;
                    Console.WriteLine("[온도 높음]부품 1라인 에어컨 가동중입니다.");
                    new SoundPlayer(Properties.Resources.siren).Play();
                }
                Console.WriteLine("==================================");
                initCommChart(list);
            }
        }

        private void MainUI_Load(object sender, EventArgs e)
        {
            
        }
        void initCommChart(List<LineEnvData> list)
        {
            for(int i=0; i < list.Count; i++)
            {
                chart1.Series["chartTemp1"].Points.Add(int.Parse(list[i].Temp1));
                chart1.Series["chartHumi1"].Points.Add(int.Parse(list[i].Humi1));
                chart1.Series["chartTemp2"].Points.Add(int.Parse(list[i].Temp2));
                chart1.Series["chartHumi2"].Points.Add(int.Parse(list[i].Humi2));

                //if()
            }
        }
    }
}
